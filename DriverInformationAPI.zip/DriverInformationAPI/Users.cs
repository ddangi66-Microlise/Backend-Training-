﻿namespace DriverInformationAPI
{
    public class Users
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}

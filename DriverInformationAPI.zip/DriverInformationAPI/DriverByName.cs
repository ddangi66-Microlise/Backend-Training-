﻿namespace DriverInformationAPI
{
    public class DriverByName
    {
        public string DriverName { get; set; }
    }
}

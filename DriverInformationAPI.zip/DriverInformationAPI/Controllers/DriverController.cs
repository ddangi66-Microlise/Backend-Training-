﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;

namespace DriverInformationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriverController : ControllerBase
    {
        public readonly IConfiguration _configuration;
        IDBConnection _connection;

        public DriverController(IConfiguration configuration)
        {
            _configuration = configuration;
            //_connection = connection;
        }

        [HttpGet]
        [Route("GetAllDrivers")]
        public string GetDriver()
        {
          
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DriverAppCon").ToString());
            SqlDataAdapter adapter = new SqlDataAdapter("FetchDriverDetails", con);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            List<Driver> drivers = new List<Driver>();
            Response response = new Response();
            if (dataTable.Rows.Count > 0)
            {
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    Driver driver = new Driver();
                    driver.Id = Convert.ToInt32(dataTable.Rows[i]["Id"]);
                    driver.Name = Convert.ToString(dataTable.Rows[i]["Name"]);
                    driver.Mobile = Convert.ToString(dataTable.Rows[i]["Mobile"]);
                    driver.DOB = Convert.ToString(dataTable.Rows[i]["DOB"]);
                    drivers.Add(driver);
                }
            }
            if (drivers.Count > 0)
            {
                return JsonConvert.SerializeObject(drivers);
            }
            else
            {
                response.StatusCode = 404;
                response.ErrorMessage = "No Data Found";
                return JsonConvert.SerializeObject(response);
            }
        }

        [HttpPost]
        [Route("AddDriver")]
        public string AddDriver(Driver driver)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DriverAppCon").ToString());
            SqlCommand cmd = new SqlCommand("AddDriver", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("Name", driver.Name);
            cmd.Parameters.AddWithValue("Mobile", driver.Mobile);
            cmd.Parameters.AddWithValue("DOB", driver.DOB);
            con.Open();
            int k = cmd.ExecuteNonQuery();
            con.Close();
            if (k != 0)
            {
                return "Driver Added Sucessfully..!";
            }
            else
            {
                return "Some error occured while inserting the data...!";
            }
        }

        [HttpGet]
        [Route("GetDriverByName/{driverName}")]
        public string AddDriverByName(string driverName)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DriverAppCon").ToString());
            SqlDataAdapter adapter = new SqlDataAdapter("GetDriverByName", con);
            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            adapter.SelectCommand.Parameters.AddWithValue("@Name", driverName);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            Driver driverData = new Driver();
            Response response = new Response();
            if (dataTable.Rows.Count > 0)
            {
                driverData.Id = Convert.ToInt32(dataTable.Rows[0]["Id"]);
                driverData.Name = Convert.ToString(dataTable.Rows[0]["Name"]);
                driverData.Mobile = Convert.ToString(dataTable.Rows[0]["Mobile"]);
                driverData.DOB = Convert.ToString(dataTable.Rows[0]["DOB"]);

            }
            if (driverData != null)
            {
                return JsonConvert.SerializeObject(driverData);
            }
            else
            {
                response.StatusCode = 404;
                response.ErrorMessage = "No Data Found";
                return JsonConvert.SerializeObject(response);
            }
        }

        [HttpPut]
        [Route("UpdateDriverByID/{id}")]
        public string UpdateDriverByName(int id, Driver driver)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DriverAppCon").ToString());
            SqlCommand cmd = new SqlCommand("UpdateDriverByID", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("Id", id);
            cmd.Parameters.AddWithValue("Name", driver.Name);
            cmd.Parameters.AddWithValue("Mobile", driver.Mobile);
            cmd.Parameters.AddWithValue("DOB", driver.DOB);
            con.Open();
            int k = cmd.ExecuteNonQuery();
            con.Close();
            if (k != 0)
            {
                return "Driver Updated Sucessfully..!";
            }
            else
            {
                return "Some error occured while updating the data...!";
            }
        }


        [HttpDelete]
        [Route("DeleteDriverById/{id}")]
        public string DeleteDriverById(int id)
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DriverAppCon").ToString());
            SqlCommand cmd = new SqlCommand("DeleteDriverById", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("Id", id);
            con.Open();
            int k = cmd.ExecuteNonQuery();
            con.Close();
            if (k != 0)
            {
                return "Driver Deleted Sucessfully..!";
            }
            else
            {
                return "Some error occured while deleting the data...!";
            }
        }

    }
}

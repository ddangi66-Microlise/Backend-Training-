﻿using System.Data.SqlClient;

namespace DriverInformationAPI;

public interface IDBConnection
{
    SqlConnection DBConnectionstring();
}

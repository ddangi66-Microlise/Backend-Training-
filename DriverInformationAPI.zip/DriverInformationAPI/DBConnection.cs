﻿using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace DriverInformationAPI;

public class DBConnection : IDBConnection
{
    public readonly IConfiguration _configuration;

    public DBConnection(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public SqlConnection DBConnectionstring()
    {
        return new SqlConnection(_configuration.GetConnectionString("DriverAppCon").ToString());
    }
}

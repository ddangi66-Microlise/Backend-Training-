﻿namespace DriverInformationAPI
{
    public class Driver
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Mobile { get; set; }
        public string DOB { get; set; }
    }
}

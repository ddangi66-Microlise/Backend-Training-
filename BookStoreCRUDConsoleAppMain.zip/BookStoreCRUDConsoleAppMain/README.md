# Book-Store-CRUD-console-app
This is a simple CRUD console application written in C# to demonstrate CRUD operations
### USERNAME: abhishek
### PASSWORD: 4444
![Screenshot (120)](https://user-images.githubusercontent.com/40319846/103369356-03217f00-4af2-11eb-9523-d8a5ff397b57.png)
![Screenshot (121)](https://user-images.githubusercontent.com/40319846/103369362-07e63300-4af2-11eb-95ae-f384dbb068af.png)
